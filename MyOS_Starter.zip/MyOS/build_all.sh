#!/bin/bash
make
./build_iso.sh
./build_usb_img.sh
