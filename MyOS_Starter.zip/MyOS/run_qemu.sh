#!/bin/bash
qemu-system-i386 -cdrom myos.iso -m 256M
